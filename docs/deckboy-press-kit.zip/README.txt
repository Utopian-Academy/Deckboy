DECKBOY PRESS KIT

Website: https://utopian-academy.github.io/Deckboy/
Download: https://github.com/Utopian-Academy/Deckboy/releases/latest
Source: https://github.com/Utopian-Academy/Deckboy
More images, MP4 clips and trailer: https://utopian-academy.github.io/Deckboy/press.html

CONTENTS AND CAPTIONS
press-copy.txt: product facts, short descriptions and workflow copy. The date
and release used to check the feature claims are at the top of that file.
images/desk-*.png: v0.99.419, three themes, the bundled layers and titles example.
images/master-tracker.png: v0.99.417 pattern tracker, sections and action cells.
images/phone-controller.png: complete v0.99.417 phone controller.
images/social-card.png: 1280 x 640 sharing card with the current desk capture.
images/social-card-performance.png: 1280 x 640 sharing card for the GPU effects and
transitions: a real output frame, a Portal transition half way.
demos/: v0.99.419 video playback, effects and scopes; earlier fixture and Mic captures.
CAPTURE-NOTES.md: dates, source versions and descriptions for each capture.

CREDIT AND REUSE
Deckboy project artwork and product copy: Deckboy Contributors,
GPL-3.0-or-later; the licence text is included as LICENSE.txt.
Suggested credit: Deckboy / Utopian Academy.
Source files: https://github.com/Utopian-Academy/Deckboy/tree/main/docs

The video-playback GIF includes trimmed Tears of Steel footage, Blender
Foundation, CC BY 3.0, shown inside Deckboy with the original audio removed.
See PLAYBACK-CREDITS.txt. The other captures use Deckboy-generated material
and the bundled examples. The Mic demo explicitly uses a test signal.
No music is bundled in this archive. Videos on the press page have their own
music credits and permissions; those terms are not replaced by this kit.
