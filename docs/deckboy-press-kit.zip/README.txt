DECKBOY PRESS KIT

Website: https://utopian-academy.github.io/Deckboy/
Download: https://github.com/Utopian-Academy/Deckboy/releases/latest
Source: https://github.com/Utopian-Academy/Deckboy
More images, MP4 clips and trailer: https://utopian-academy.github.io/Deckboy/press.html

CONTENTS AND CAPTIONS
press-copy.txt: product facts, short descriptions and workflow copy. The date
and release used to check the feature claims are at the top of that file.
images/desk-*.png: v0.99.417, three themes, built-in patterns and Swirl.
images/master-tracker.png: v0.99.417 pattern tracker, sections and action cells.
images/phone-controller.png: complete v0.99.417 phone controller.
images/social-card.png: 1280 x 640 sharing card with the current desk capture.
demos/: animated GIFs of cue taking, effects, scopes, fixtures and a Mic cue.
CAPTURE-NOTES.md: dates, source versions and descriptions for each capture.

CREDIT AND REUSE
Deckboy project artwork and product copy: Deckboy Contributors,
GPL-3.0-or-later; the licence text is included as LICENSE.txt.
Suggested credit: Deckboy / Utopian Academy.
Source files: https://github.com/Utopian-Academy/Deckboy/tree/main/docs

The included captures use Deckboy-generated material and a local test page.
The Mic demo explicitly uses a test signal. No third-party film or music is
bundled. Other images and the trailer on the press page have their own credits
and terms; those terms are not replaced by this kit.
